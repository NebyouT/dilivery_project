import 'package:flutter/material.dart';
import 'order_food_page.dart'; // Import the order food page

class FoodDetailPage extends StatelessWidget {
  final String foodName;
  final String foodDescription;
  final double foodPrice;
  final String foodImageUrl;

  FoodDetailPage({
    required this.foodName,
    required this.foodDescription,
    required this.foodPrice,
    required this.foodImageUrl,
  });

  @override
  Widget build(BuildContext context) {
    final String userName = "John Doe"; // Replace with actual user name logic

    return Scaffold(
      appBar: AppBar(
        title: Text(foodName),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.network(
                foodImageUrl,
                height: 250,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              foodName,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Text(
              'Price: \$${foodPrice.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 20, color: Colors.grey[700]),
            ),
            SizedBox(height: 16.0),
            Text(
              foodDescription,
              style: TextStyle(fontSize: 16),
            ),
            Spacer(),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => OrderFoodPage(
                        hotelName:
                            'Hotel Example', // Replace with actual hotel name
                        foodName: foodName,
                        foodDescription: foodDescription,
                        foodPrice: foodPrice,
                        userName: userName,
                      ),
                    ),
                  );
                },
                child: Text('Order Now'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
