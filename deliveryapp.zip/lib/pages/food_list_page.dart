import 'package:flutter/material.dart';
import 'food_detail_page.dart'; // Import the food detail page

class FoodListPage extends StatelessWidget {
  final String hotelName;

  FoodListPage({required this.hotelName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('$hotelName Menu'),
      ),
      body: ListView(
        padding: EdgeInsets.all(8.0),
        children: List.generate(10, (index) {
          final foodName = 'Food Item ${index + 1}';
          final foodDescription = 'Description of Food Item ${index + 1}';
          final foodPrice = (index + 1) * 5.0;
          final foodImageUrl = 'https://via.placeholder.com/150';

          return Card(
            child: ListTile(
              leading: Image.network(
                foodImageUrl,
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
              title: Text(foodName),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(foodDescription),
                  Text('Price: \$${foodPrice.toStringAsFixed(2)}'),
                ],
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FoodDetailPage(
                      foodName: foodName,
                      foodDescription: foodDescription,
                      foodPrice: foodPrice,
                      foodImageUrl: foodImageUrl,
                    ),
                  ),
                );
              },
            ),
          );
        }),
      ),
    );
  }
}
