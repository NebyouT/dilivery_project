import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  // Placeholder user data
  final Map<String, String> userData = {
    'firstName': 'John',
    'lastName': 'Doe',
    'username': 'johndoe',
    'email': 'johndoe@example.com',
    'phoneNumber': '+1234567890',
  };

  void _logout(BuildContext context) {
    // Implement logout logic here
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: AssetImage(
                  'assets/profile_photo.png'), // Replace with actual profile photo
            ),
            SizedBox(height: 16.0),
            Text(
              '${userData['firstName']} ${userData['lastName']}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Text(
              '@${userData['username']}',
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
            SizedBox(height: 16.0),
            ListTile(
              leading: Icon(Icons.email),
              title: Text(userData['email']!),
            ),
            ListTile(
              leading: Icon(Icons.phone),
              title: Text(userData['phoneNumber']!),
            ),
            Spacer(),
            ElevatedButton(
              onPressed: () => _logout(context),
              child: Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}
