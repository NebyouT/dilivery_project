import 'package:flutter/material.dart';
import 'orders_page.dart'; // Make sure to have this page implemented
import 'bottom_nav_bar.dart';

class OrderFoodPage extends StatefulWidget {
  final String hotelName;
  final String foodName;
  final String foodDescription;
  final double foodPrice;
  final String userName;
  final int? initialQuantity;
  final String? initialLocation;

  OrderFoodPage({
    required this.hotelName,
    required this.foodName,
    required this.foodDescription,
    required this.foodPrice,
    required this.userName,
    this.initialQuantity,
    this.initialLocation,
  });

  @override
  _OrderFoodPageState createState() => _OrderFoodPageState();
}

class _OrderFoodPageState extends State<OrderFoodPage> {
  late TextEditingController _locationController;
  late int _quantity;
  late double _totalPrice;

  @override
  void initState() {
    super.initState();
    _quantity = widget.initialQuantity ?? 1;
    _locationController =
        TextEditingController(text: widget.initialLocation ?? '');
    _calculateTotalPrice();
  }

  void _calculateTotalPrice() {
    setState(() {
      _totalPrice =
          widget.foodPrice * _quantity * 1.05; // Including 5% service charge
    });
  }

  void _placeOrder() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
      ),
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(16.0),
          height: MediaQuery.of(context).size.height * 0.5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Text(
                  'Order Confirmation',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(height: 16.0),
              Text('Order ID: 123456', style: TextStyle(fontSize: 18)),
              SizedBox(height: 8.0),
              Text('Bank Account: 1234 5678 9101 1121',
                  style: TextStyle(fontSize: 18)),
              SizedBox(height: 8.0),
              Text('Total Price: \$${_totalPrice.toStringAsFixed(2)}',
                  style: TextStyle(fontSize: 18)),
              SizedBox(height: 16.0),
              Text(
                'Please deposit the total amount to the above bank account. Your order will be pending until payment is confirmed. We will contact you once the payment is received to inform you about the delivery time.',
                style: TextStyle(fontSize: 16),
              ),
              Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => BottomNavBar()),
                      );
                    },
                    child: Text('OK'),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.green,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('Cancel'),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Place Order'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Hotel: ${widget.hotelName}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Text(
              'Food: ${widget.foodName}',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 8.0),
            Text(
              'Description: ${widget.foodDescription}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8.0),
            Text(
              'Price: \$${widget.foodPrice.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8.0),
            Text(
              'User: ${widget.userName}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: _locationController,
              decoration: InputDecoration(
                labelText: 'Your Location',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16.0),
            Row(
              children: [
                Text('Quantity:', style: TextStyle(fontSize: 16)),
                SizedBox(width: 8.0),
                IconButton(
                  icon: Icon(Icons.remove),
                  onPressed: () {
                    if (_quantity > 1) {
                      setState(() {
                        _quantity--;
                        _calculateTotalPrice();
                      });
                    }
                  },
                ),
                Text(_quantity.toString(), style: TextStyle(fontSize: 16)),
                IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      _quantity++;
                      _calculateTotalPrice();
                    });
                  },
                ),
              ],
            ),
            SizedBox(height: 16.0),
            Text(
              'Total Price: \$${_totalPrice.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Spacer(),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  _placeOrder();
                },
                child: Text('Order Now'),
                style: ElevatedButton.styleFrom(
                  primary: Colors.blue,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18.0),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
