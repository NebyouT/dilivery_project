import 'package:flutter/material.dart';
import 'package:deliveryapp/pages/order_food_page.dart';

class OrdersPage extends StatelessWidget {
  final List<Map<String, dynamic>> orders = [
    {
      'hotelName': 'Hotel Example 1',
      'foodName': 'Food Item 1',
      'foodDescription': 'Description of Food Item 1',
      'foodPrice': 10.0,
      'quantity': 2,
      'totalPrice': 21.0, // Including 5% service charge
      'location': 'User Location 1',
    },
    {
      'hotelName': 'Hotel Example 2',
      'foodName': 'Food Item 2',
      'foodDescription': 'Description of Food Item 2',
      'foodPrice': 15.0,
      'quantity': 1,
      'totalPrice': 15.75, // Including 5% service charge
      'location': 'User Location 2',
    },
  ];

  void _cancelOrder(int index) {
    // Implement order cancellation logic here
    // For now, we'll just remove the order from the list
    orders.removeAt(index);
  }

  void _editOrder(BuildContext context, int index) {
    // Implement order editing logic here
    // For now, we'll just navigate to the order food page with pre-filled data
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => OrderFoodPage(
          hotelName: orders[index]['hotelName'],
          foodName: orders[index]['foodName'],
          foodDescription: orders[index]['foodDescription'],
          foodPrice: orders[index]['foodPrice'],
          userName: 'John Doe', // Replace with actual user name logic
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Orders'),
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(8.0),
        itemCount: orders.length,
        itemBuilder: (context, index) {
          final order = orders[index];
          return Card(
            child: ListTile(
              title: Text('${order['foodName']} from ${order['hotelName']}'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Description: ${order['foodDescription']}'),
                  Text('Quantity: ${order['quantity']}'),
                  Text('Location: ${order['location']}'),
                  Text(
                      'Total Price: \$${order['totalPrice'].toStringAsFixed(2)}'),
                ],
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () => _editOrder(context, index),
                  ),
                  IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () => _cancelOrder(index),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
