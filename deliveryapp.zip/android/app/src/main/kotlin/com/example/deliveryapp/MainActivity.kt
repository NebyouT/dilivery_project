package com.example.deliveryapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
